package Hotel;

public enum Categoria {
	SUPERLUXE, LUXE, NORMAL;
}
