import json

def menu():
    while True:
        try:
            seleccio = int(input("Menu:\n 1. Afegir Contancte\n 2. Mostrar Contactes\n 3. Cercar Contacte\n 4. Modificar Contacte\n 5. Esborrar Contacte\n 6. Importa desde Fitxer\n 7. Exporta a Fitxer\n 8. Sortir\n   Selecció: "))

            if seleccio not in (1, 2, 3, 4, 5, 6, 7, 8):
                raise

            return seleccio

        except:
            print("La selecció ha de ser un nombre entre 1 i 8")

def afegirContacte():
    print("Dades usuari: ")

    nom = input("   Nom: ")
    mail = input("   Mail: ")
    telefon = input("   Telèfon: ")
    poblacio = input("   Població: ")

    while True:
        try:
            newsletter = input("   Newsletter [S / N]: ").lower()

            if newsletter == "s":
                newsletter = "Si"
            
            elif newsletter == "n":
                newsletter = "No"
            
            else:
                raise

            break
        
        except:
            print("La resposta ha de ser: 's' o 'n'")

    ID = None

    for i in range(len(contactes) + 1):
        if i == len(contactes):
            try:
                ID = contactes[i - 1]["id"] + 1
            
            except:
                ID = 1
            

    contactes.append({"id": ID, "nom": nom, "mail": mail, "telefon": telefon, "poblacio": poblacio, "newsletter": newsletter})
    ids.append(contactes[len(contactes) - 1]["id"])
             
def mostrarAgenda(contactes):
    print()
    def get_name(employee):
        return employee.get('nom')

    def get_id(employee):
        return employee.get('id')
    
    def get_mail(employee):
        return employee.get('mail')
    
    def get_telefon(employee):
        return employee.get('telefon')
    
    def get_poblacio(employee):
        return employee.get('poblacio')

    def get_newsletter(employee):
        return employee.get('newsletter')

    formaOrdre = int(input("Com els vols ordenats: \n 1-ID\n 2-Nom\n 3-Mail\n 4-Telèfon\n 5-Població\n 6-Newsletter\n  Selecció: "))

    if formaOrdre == 1:
        contactes.sort(key=get_id)

    elif formaOrdre == 2:
        contactes.sort(key=get_name)

    elif formaOrdre == 3:
        contactes.sort(key=get_mail)

    elif formaOrdre == 4:
        contactes.sort(key=get_telefon)

    elif formaOrdre == 5:
        contactes.sort(key=get_poblacio)

    elif formaOrdre == 6:
        contactes.sort(key=get_newsletter)

    print("ID     NOM     TELÈFON     MAIL      POBLACIÓ     NEWSLETTER")
    for i in range(len(contactes)):
        mostrarContacte(contactes[i])
        
        print()

def mostrarContacte(contacte):
    for i in contacte.values():
        print(f"{i}      ", end="")

def cercarContacte():
    print()
    nom = input("Nom del contacte a cercar: ")
    resultats = []

    for contacte in contactes:
        if contacte["nom"].startswith(nom): 
            resultats.append(contacte)

    mostrarAgenda(resultats)
    
def modificarContacte():
    mostrarAgenda(contactes)

    while True:
        try:
            id = int(input("Selecciona id: "))

            if id not in ids:
                raise TypeError
            
            for contacte in contactes:
                if contacte["id"] == id:
                    print("hola")
                    
                    return

        except ValueError:
            print("Ha de ser un nombre")

        except TypeError:
            print("Selecciona una ID vàlida")

def esborrarContacte():
    mostrarAgenda(contactes)
    
    while True:
        try:
            id = int(input("Selecciona id: "))

            if id not in ids:
                raise TypeError
            
            for contacte in contactes:
                if contacte["id"] == id:
                    contactes.remove(contacte)
                    ids.remove(id)

                    return


        except ValueError:
            print("Ha de ser un nombre")

        except TypeError:
            print("Selecciona una ID vàlida")

def importaFitxer():
    global contactes, ids

    with open(jsonFile) as f:
        try:
            contactes = json.load(f)
            ids = []
            for i in contactes:
                ids.append(i["id"])

        except:
            print("El fitxer JSON està buit")

def exportaFitxer():
    with open(jsonFile, "w") as f:
        json.dump(contactes, f)

            
contactes = []
ids = []

jsonFile = "agenda.json"

while True:
    seleccio = menu()

    if seleccio == 1:
        afegirContacte()

    elif seleccio == 2:
        mostrarAgenda(contactes)
    
    elif seleccio == 3:
        cercarContacte()

    elif seleccio == 4:
        modificarContacte()

    elif seleccio == 5:
        esborrarContacte()
    
    elif seleccio == 6:
        importaFitxer()

    elif seleccio == 7:
        exportaFitxer()
    
    elif seleccio == 8:
        exit()