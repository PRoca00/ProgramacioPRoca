file = "noms.txt"

with open(file) as file:
    # Mètode 1
    print(file.read())

    # Mètode 2
    # print("------------------------------")

    # for line in file:
    #     print(line.strip())

    # Mètode 3
    # print("------------------------------")

    # lines = file.readlines()

    # for line in lines:
    #     print(line.strip())