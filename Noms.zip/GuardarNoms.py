with open("noms.txt", "w") as file:
    noms = ""

    for i in range(5):
        nom = input("Introdueix un nom: ")

        if i == 0:
            noms += nom
        else:
            noms += "\n" + nom
    
    file.write(noms)
    